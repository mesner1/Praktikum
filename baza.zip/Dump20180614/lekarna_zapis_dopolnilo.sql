-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: lekarna
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `zapis_dopolnilo`
--

DROP TABLE IF EXISTS `zapis_dopolnilo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zapis_dopolnilo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dopolnilo_id` int(11) NOT NULL,
  `zapis_id` int(11) NOT NULL,
  `kolicina` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_zapis_zd_zdravilo/dopolnilo1_idx` (`dopolnilo_id`),
  KEY `fk_zapis_zd_zapis1_idx` (`zapis_id`),
  CONSTRAINT `fk_zapis_zd_zapis1` FOREIGN KEY (`zapis_id`) REFERENCES `zapis` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_zapis_zd_zdravilo/dopolnilo1` FOREIGN KEY (`dopolnilo_id`) REFERENCES `dopolnilo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zapis_dopolnilo`
--

LOCK TABLES `zapis_dopolnilo` WRITE;
/*!40000 ALTER TABLE `zapis_dopolnilo` DISABLE KEYS */;
INSERT INTO `zapis_dopolnilo` VALUES (16,9,8,'1'),(17,11,8,'1'),(18,12,8,'1'),(19,9,9,'1'),(20,11,9,'1'),(21,12,9,'1'),(22,9,10,'1'),(23,11,10,'1'),(24,12,10,'1'),(25,10,11,'1'),(26,11,11,'1'),(27,4,12,'1'),(28,6,12,'1'),(29,9,12,'1'),(30,10,12,'1'),(31,4,13,'1'),(32,6,13,'1'),(33,9,13,'1'),(34,10,13,'1'),(35,7,14,'1'),(36,8,14,'1'),(37,9,14,'1'),(38,7,15,'1'),(39,8,15,'1'),(40,9,15,'1'),(44,9,16,'2'),(45,4,17,'1'),(46,6,17,'1'),(47,8,17,'1'),(48,1,18,'1'),(49,1,19,'1'),(50,2,19,'1'),(51,3,19,'1'),(52,4,19,'1'),(53,5,19,'1'),(54,6,19,'1'),(55,7,19,'1'),(56,8,19,'1'),(57,9,19,'1'),(58,10,19,'1'),(59,6,20,'1'),(60,7,20,'1'),(61,8,20,'1'),(62,9,20,'1'),(63,10,20,'1'),(64,11,20,'1'),(65,12,20,'1'),(66,13,20,'1'),(67,14,20,'1'),(68,15,20,'1'),(69,6,21,'1'),(70,7,21,'1'),(71,8,21,'1'),(72,9,21,'1'),(73,10,21,'1'),(74,11,21,'1'),(75,12,21,'1'),(76,13,21,'1'),(77,14,21,'1'),(78,15,21,'1'),(89,1,22,'1'),(90,2,22,'1'),(91,3,22,'1'),(92,4,22,'1'),(93,5,22,'1'),(94,6,22,'1'),(95,7,22,'1'),(96,8,22,'1'),(97,9,22,'1'),(98,10,22,'1'),(109,1,23,'1'),(110,1,24,'1');
/*!40000 ALTER TABLE `zapis_dopolnilo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-14 10:12:29
