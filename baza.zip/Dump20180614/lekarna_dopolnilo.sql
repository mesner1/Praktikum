-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: lekarna
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dopolnilo`
--

DROP TABLE IF EXISTS `dopolnilo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dopolnilo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(45) NOT NULL,
  `naRecept` tinyint(4) NOT NULL,
  `trajanje` int(11) NOT NULL,
  `opis` varchar(255) DEFAULT NULL,
  `embalaza` varchar(255) DEFAULT NULL,
  `slika` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dopolnilo`
--

LOCK TABLES `dopolnilo` WRITE;
/*!40000 ALTER TABLE `dopolnilo` DISABLE KEYS */;
INSERT INTO `dopolnilo` VALUES (1,'paracetamol',1,11,'Zniževanje vročine, lajšanje bolečin.','paket','https://www.biofarm.ro/images/produse/147.png'),(2,'antidepresiv',1,21,'Izboljševanje razpoloženja.','steklenička','https://i.pinimg.com/originals/31/c8/bb/31c8bbdcdbab72769dc877821b51290b.jpg'),(3,'antikoagulant',1,14,'Preprečitev strjevanja krvi.','steklenička','https://pbmc.ru/public/040477906e872fa9ab4e.jpg'),(4,'aspirin',0,5,'Za lajšanje bolečin.','paket','http://www.thediabeticfriend.org/wp-content/uploads/2011/06/aspirin.png'),(5,'ibuprofen',1,16,'Proti revmatičnim boleznim, artropatijam. Tudi za lajšanje bolečin.','paket','http://www.relonchem.com/images/product_range/Ibuprofen400mg_24.png'),(6,'naproxen',0,7,'Za lajšanje bolečin.','paket','http://www.arsonspharma.com/PDetails/pics/AR-Naproxen.png'),(7,'antihistaminik',1,18,'Preprečuje biološki učinek histamina.','tuba','https://www.aerius.ca/static/media/images/products/aerius-dual-action-allergy-sinus-tablets.png'),(8,'opioid',1,14,'Za lajšanje bolečin.','paket','https://storage.googleapis.com/stateless-physweekly-com/2016/03/Opioids-FutureUse-Adolescents-Feature.png'),(9,'zdravilo proti kašlju',0,6,'Proti kašlju.','steklenička','https://www.farmedica.si/images/catalogitemmain/farmedica-izdelek-prospan-sirup-2017.png'),(10,'pršilo za nos',0,15,'Proti nahodu in vnetju sinusov.','pršilo','https://www.tosama.si/iimg/3964/300x350/i.png'),(11,'zdravilo z dimenhidrinatom',0,12,'Proti vrtoglavici, slabosti, bruhanju, slabosti med vožnjo ...','paket','http://www.tilman.be/sites/default/files/styles/uc_product_full/public/Antimetil_DE_EN.png?itok=EJ92X1Oj'),(12,'gel za noge',0,10,'Za otekle in boleče noge.','paket','https://www.dm-drogeriemarkt.si/linkableblob/si_homepage/593134/data/162456-hladilni-gel-za-noge-v-tubi-12-2-2015-slika-data.png?v=1440055548000'),(13,'krema (glivične okužbe)',0,20,'Proti glivičnim okužbam.','paket','https://www.moja-lekarna.com/content/images/thumbs/0038124_exoderil-za-glivicne-okuzbe-nohtov-15-g-kreme_550.jpeg'),(14,'prah z vitaminom C',0,34,'Prehransko dopolnilo za vzdrževanje zdravih sklepov.','tuba','http://rsi.rs/wp-content/uploads/2013/12/Vitamin-C-u-prahu-425x283.png'),(15,'tablete krvni tlak',1,13,'Zniževanje krvnega tlaka.','paket','https://www.krka.biz/media/products/si/rx/groupthumb/2015/PRENESSA2_SI_8mg_30tab_in_90tab_web.jpg');
/*!40000 ALTER TABLE `dopolnilo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-14 10:12:29
